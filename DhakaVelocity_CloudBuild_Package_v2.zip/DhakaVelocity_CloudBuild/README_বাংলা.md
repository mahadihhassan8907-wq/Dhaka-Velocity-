# Dhaka Velocity — মোবাইল থেকে Cloud APK Build

এটি একটি **প্রাথমিক Unity greybox prototype-এর cloud-build প্রস্তুত সোর্স**। এটি সম্পূর্ণ GTA-মানের গেম নয় এবং এই ZIP-এ APK নেই। GitHub Actions-এ Unity license সেটআপের পর অনলাইন runner APK বানানোর চেষ্টা করবে। প্রথম build এখনো চালিয়ে যাচাই করা হয়নি; কোনো compile/build error দেখা দিলে তা ঠিক করতে হবে।

## কী যোগ করা হয়েছে
- Unity 6.3 LTS project scaffold (`6000.3.27f2`)
- Android ARM64 test APK-এর জন্য GameCI workflow
- Unity Personal license activation file তৈরির workflow
- CI-তে GUI dialog ছাড়া procedural demo scene তৈরি
- APK output: `build/Android/DhakaVelocity.apk`
- প্রথম APK হলো Development/test build এবং debug signing-এ তৈরি; Play Store/release build নয়

## যা এখনও অসম্পূর্ণ
- 3D শহর আপাতত greybox/primitive geometry; বাস্তবসম্মত art assets নেই
- গাড়ি ও traffic physics প্রাথমিক পর্যায়ে
- Garage, বহু গাড়ি, mission system, save system, production optimization, multiplayer নেই
- Unity Editor-এ compile বা বাস্তব Android device-এ test করা হয়নি

## শুধু Android ফোন থেকে ফ্রি build করার পথ

### ধাপ ১ — GitHub-এ repository তৈরি
1. https://github.com এ একটি account খুলুন বা sign in করুন।
2. `New repository` চাপুন, নাম দিন `DhakaVelocity`।
3. প্রথমে **Private** রাখুন। Description/README যোগ না করলেও চলবে।
4. এই ZIP extract করে ZIP-এর ভেতরের ফাইল/ফোল্ডারগুলো repository-র root-এ upload করুন। `Assets`, `Packages`, `ProjectSettings`, `.github`, `.gitignore` যেন root-এ থাকে; ZIP-এর বাইরের অতিরিক্ত parent folder যেন না থাকে।
5. GitHub web-এ `.github/workflows` ফোল্ডার তৈরি/আপলোড হয়েছে কি না দেখুন।

### ধাপ ২ — Unity Personal license তৈরি (একবার)
1. https://id.unity.com এ Unity account খুলুন বা sign in করুন। Unity Personal-এর eligibility হলো আগের ১২ মাসে revenue/funding US$200,000-এর বেশি নয়।
2. GitHub repository → **Actions** → `Unity Personal License Activation File` workflow → **Run workflow** চাপুন।
3. শেষ হলে ওই run-এর **Artifacts** থেকে `Unity-Manual-Activation-File` ZIP নামিয়ে extract করুন। ভেতরের `.alf` ফাইলটি নিন।
4. https://license.unity3d.com/manual এ `.alf` আপলোড করে Personal license `.ulf` ডাউনলোড করুন।
5. GitHub repository → **Settings → Secrets and variables → Actions → New repository secret**-এ তিনটি secret যোগ করুন:
   - `UNITY_LICENSE` = `.ulf` ফাইলটি text editor-এ খুলে সম্পূর্ণ contents
   - `UNITY_EMAIL` = Unity account-এর email
   - `UNITY_PASSWORD` = Unity account-এর password

**খুব গুরুত্বপূর্ণ:** Unity password বা `.ulf` contents কাউকে chat-এ পাঠাবেন না। শুধু নিজের GitHub repository-র Actions Secrets-এ দিন। Two-factor login ব্যবহার করলে account security আরও ভালো।

### ধাপ ৩ — APK Build
1. GitHub repository → **Actions** খুলুন।
2. `Build Dhaka Velocity Android APK` নির্বাচন করে **Run workflow** চাপুন।
3. build সফল হলে ওই run-এর নিচে **Artifacts** থেকে `DhakaVelocity-Android-Test-APK` নামান।
4. ZIP extract করে `DhakaVelocity.apk` ফোনে install করুন। Android জিজ্ঞেস করলে শুধু আপনার ডাউনলোড করা APK-এর জন্য অনুমতি দিন।

## খরচ ও সীমা
- GitHub Free ব্যক্তিগত account-এ private repository-র জন্য প্রতি মাসে 2,000 Actions minutes অন্তর্ভুক্ত। অন্তর্ভুক্ত সীমা শেষ হলে অতিরিক্ত usage billed হতে পারে; খরচ এড়াতে GitHub Billing-এ spending limit `$0` রাখুন/কোনো paid upgrade বা larger runner চালু করবেন না। Public repository-তে standard runner usage free, কিন্তু code সবার জন্য প্রকাশ্য হবে।
- Unity Personal eligible হলে বিনামূল্যে; Unity terms অনুযায়ী ১২ মাসের revenue/funding threshold US$200,000।
- GameCI, GitHub Actions ও Unity version support বদলাতে পারে। প্রথম cloud run-এ license, package resolution, editor API বা Android toolchain error হলে সেই error log দেখে সংশোধন করতে হবে।
- APK size এখনো জানা নেই; build না হওয়া পর্যন্ত 100–200 MB নিশ্চিত করা যাবে না।

## নিরাপত্তা
- Repository private রাখাই সুপারিশ।
- কোনো `.ulf`, password, keystore বা API key source files-এ commit করবেন না।
- `UNITY_LICENSE`, `UNITY_EMAIL`, `UNITY_PASSWORD` কেবল GitHub Actions Secrets-এ রাখবেন।
- Workflow শুধু manual trigger-এ চলে; প্রতিটি build-এর জন্য আলাদাভাবে Run workflow চাপতে হবে।
