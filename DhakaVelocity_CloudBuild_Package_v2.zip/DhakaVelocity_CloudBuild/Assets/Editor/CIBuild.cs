#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using DhakaVelocity.EditorTools;

namespace DhakaVelocity.EditorTools
{
    public static class CIBuild
    {
        // Called by GameCI on a hosted cloud runner. Builds a test APK signed
        // with Unity's default debug keystore so it can be installed for testing.
        public static void BuildAndroid()
        {
            const string scenePath = "Assets/DhakaVelocity/DhakaVelocity_Demo.unity";
            const string outputPath = "build/Android/DhakaVelocity.apk";

            Directory.CreateDirectory("build/Android");
            DemoSceneBuilder.BuildForCI();
            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(scenePath, true)
            };

            PlayerSettings.companyName = "Dhaka Velocity Studio";
            PlayerSettings.productName = "Dhaka Velocity";
            PlayerSettings.applicationIdentifier = "com.dhakavelocity.game";
            PlayerSettings.bundleVersion = "0.1.0";
            PlayerSettings.Android.bundleVersionCode = 1;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.useCustomKeystore = false;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);

            var options = new BuildPlayerOptions
            {
                scenes = new[] { scenePath },
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.Development
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result != BuildResult.Succeeded)
            {
                throw new BuildFailedException(
                    "Dhaka Velocity Android build failed: " + report.summary.result +
                    ". Check the Unity build log in this GitHub Actions run.");
            }

            Debug.Log("Dhaka Velocity test APK created: " + Path.GetFullPath(outputPath));
        }
    }
}
#endif
