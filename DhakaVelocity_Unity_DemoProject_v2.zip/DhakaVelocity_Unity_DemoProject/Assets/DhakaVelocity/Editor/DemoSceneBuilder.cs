#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using DhakaVelocity;

namespace DhakaVelocity.EditorTools {
 public static class DemoSceneBuilder {
  [MenuItem("Dhaka Velocity/Build Playable Demo Scene")]
  public static void Build(){
   if(!EditorUtility.DisplayDialog("Build Dhaka Velocity Demo","Create a new greybox city driving scene? Current open scene changes will be replaced.","Build Scene","Cancel"))return;
   var scene=EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects,NewSceneMode.Single);
   RenderSettings.ambientLight=new Color(.58f,.62f,.68f);
   var sun=new GameObject("Sun Light").AddComponent<Light>();sun.type=LightType.Directional;sun.intensity=1.25f;sun.transform.rotation=Quaternion.Euler(48,-32,0);sun.shadows=LightShadows.Soft;
   var city=new GameObject("City Greybox");
   MakeCube("Ground",city.transform,new Vector3(0,-.6f,0),new Vector3(250,1,250),new Color(.18f,.31f,.18f),true);
   Material road=Mat(new Color(.12f,.14f,.16f));Material building=Mat(new Color(.55f,.59f,.62f));Material glass=Mat(new Color(.12f,.24f,.30f));
   for(int p=-105;p<=105;p+=42){MakeCube("East West Road",city.transform,new Vector3(0,-.08f,p),new Vector3(230,.16f,13),road,true);MakeCube("North South Road",city.transform,new Vector3(p,-.08f,0),new Vector3(13,.16f,230),road,true);}
   Random.InitState(2026);
   for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++){float px=x*42+21,pz=z*42+21;if(false)continue;float h=Random.Range(12,32);MakeCube("Building",city.transform,new Vector3(x*42f,h/2,z*42f),new Vector3(Random.Range(14,20),h,Random.Range(14,20)),building,true);MakeCube("Roof Detail",city.transform,new Vector3(x*42f,h+.2f,z*42f),new Vector3(5,.4f,5),glass,true);}
   var spawn=new GameObject("Player Spawn").transform;spawn.position=new Vector3(0,.8f,-98);spawn.rotation=Quaternion.identity;
   var car=GameObject.CreatePrimitive(PrimitiveType.Cube);car.name="Player Car";car.transform.position=spawn.position;car.transform.localScale=new Vector3(1.9f,.65f,3.8f);car.GetComponent<Renderer>().sharedMaterial=Mat(new Color(.02f,.42f,.82f));
   var rb=car.AddComponent<Rigidbody>();rb.mass=1200;rb.interpolation=RigidbodyInterpolation.Interpolate;rb.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;
   var inputGo=new GameObject("Mobile Input");var mobile=inputGo.AddComponent<MobileDriveInput>();var controller=car.AddComponent<VehicleController>();controller.mobileInput=mobile;
   var cam=Camera.main;if(!cam){var cgo=new GameObject("Main Camera");cam=cgo.AddComponent<Camera>();cgo.tag="MainCamera";}cam.transform.position=new Vector3(0,5,-108);cam.gameObject.AddComponent<FollowCamera>().target=car.transform;
   BuildUI(controller,mobile);
   var raceGo=new GameObject("Race Manager");var race=raceGo.AddComponent<CheckpointRaceManager>();race.total=5;
   Vector3[] points={new Vector3(0,.15f,-65),new Vector3(0,.15f,-22),new Vector3(63,.15f,-21),new Vector3(63,.15f,63),new Vector3(0,.15f,63)};
   for(int i=0;i<points.Length;i++){var gate=GameObject.CreatePrimitive(PrimitiveType.Cube);gate.name="Checkpoint "+(i+1);gate.transform.position=points[i];gate.transform.localScale=new Vector3(10,3,.5f);gate.GetComponent<Renderer>().sharedMaterial=Mat(new Color(.05f,.95f,.58f));var col=gate.GetComponent<BoxCollider>();col.isTrigger=true;var g=gate.AddComponent<CheckpointGate>();g.index=i;g.manager=race;}
   for(int i=0;i<4;i++){var traffic=GameObject.CreatePrimitive(PrimitiveType.Cube);traffic.name="Traffic Car";traffic.transform.position=new Vector3(i%2==0?4:-4,.55f,-70+i*42);traffic.transform.localScale=new Vector3(1.7f,.6f,3.2f);traffic.GetComponent<Renderer>().sharedMaterial=Mat(new Color(.75f,.22f,.12f));traffic.AddComponent<SimpleTrafficMover>().speed=5+i;}
   EditorSceneManager.MarkSceneDirty(scene);
   string path="Assets/DhakaVelocity/DhakaVelocity_Demo.unity";EditorSceneManager.SaveScene(scene,path);
   Selection.activeGameObject=car;
   EditorUtility.DisplayDialog("Scene Created","Playable greybox scene created. Press Play in the Editor. Build Android after testing.","OK");
  }
  static void BuildUI(VehicleController car,MobileDriveInput input){
   var canvasGo=new GameObject("HUD Canvas",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));var canvas=canvasGo.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;var scaler=canvasGo.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1920,1080);
   if(!Object.FindObjectOfType<EventSystem>())new GameObject("EventSystem",typeof(EventSystem),typeof(StandaloneInputModule));
   var speed=MakeText(canvasGo.transform,"Speed","0 KM/H",new Vector2(1,1),new Vector2(-150,-70),new Vector2(260,90),34,TextAnchor.MiddleRight);var speedComp=canvasGo.AddComponent<SpeedometerUI>();speedComp.vehicle=car;speedComp.speedText=speed;
   MakeButton(canvasGo.transform,input,DriveAction.SteerLeft,"◀",new Vector2(0,0),new Vector2(110,120));
   MakeButton(canvasGo.transform,input,DriveAction.SteerRight,"▶",new Vector2(0,0),new Vector2(235,120));
   MakeButton(canvasGo.transform,input,DriveAction.Brake,"BRAKE",new Vector2(1,0),new Vector2(-250,120));
   MakeButton(canvasGo.transform,input,DriveAction.Accelerate,"GO",new Vector2(1,0),new Vector2(-115,145));
   MakeButton(canvasGo.transform,input,DriveAction.Reverse,"REV",new Vector2(1,0),new Vector2(-115,45));
   MakeButton(canvasGo.transform,input,DriveAction.Nitro,"N₂O",new Vector2(1,0),new Vector2(-390,120));
  }
  static Text MakeText(Transform parent,string n,string value,Vector2 anchor,Vector2 pos,Vector2 size,int font,TextAnchor align){var go=new GameObject(n,typeof(RectTransform),typeof(Text));go.transform.SetParent(parent,false);var rt=go.GetComponent<RectTransform>();rt.anchorMin=rt.anchorMax=anchor;rt.anchoredPosition=pos;rt.sizeDelta=size;var t=go.GetComponent<Text>();t.text=value;t.font=Resources.GetBuiltinResource<Font>("Arial.ttf");t.fontSize=font;t.alignment=align;t.color=Color.white;return t;}
  static void MakeButton(Transform parent,MobileDriveInput input,DriveAction action,string label,Vector2 anchor,Vector2 pos){var go=new GameObject(label+" Button",typeof(RectTransform),typeof(Image),typeof(Button),typeof(MobileHoldButton));go.transform.SetParent(parent,false);var rt=go.GetComponent<RectTransform>();rt.anchorMin=rt.anchorMax=anchor;rt.anchoredPosition=pos;rt.sizeDelta=new Vector2(112,100);var image=go.GetComponent<Image>();image.color=new Color(.03f,.09f,.14f,.78f);var b=go.GetComponent<Button>();b.targetGraphic=image;var hold=go.GetComponent<MobileHoldButton>();hold.input=input;hold.action=action;MakeText(go.transform,"Label",label,new Vector2(.5f,.5f),Vector2.zero,new Vector2(108,96),22,TextAnchor.MiddleCenter);}
  static GameObject MakeCube(string n,Transform parent,Vector3 pos,Vector3 scale,Color color,bool collider){var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.name=n;go.transform.SetParent(parent);go.transform.position=pos;go.transform.localScale=scale;go.GetComponent<Renderer>().sharedMaterial=Mat(color);if(!collider)Object.DestroyImmediate(go.GetComponent<Collider>());return go;}
  static Material Mat(Color c){var shader=Shader.Find("Universal Render Pipeline/Lit");if(!shader)shader=Shader.Find("Standard");var m=new Material(shader);m.color=c;return m;}
 }
}
#endif