using UnityEngine;
namespace DhakaVelocity {
 public sealed class SimpleTrafficMover : MonoBehaviour {
  public float speed=7f; public float minZ=-115,maxZ=115;
  void Update(){transform.position+=Vector3.forward*speed*Time.deltaTime;if(transform.position.z>maxZ)transform.position=new Vector3(transform.position.x,transform.position.y,minZ);}
 }
}