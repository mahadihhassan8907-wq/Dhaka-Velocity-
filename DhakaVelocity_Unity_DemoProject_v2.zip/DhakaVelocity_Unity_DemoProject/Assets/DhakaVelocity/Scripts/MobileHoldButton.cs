using UnityEngine;
using UnityEngine.EventSystems;
namespace DhakaVelocity {
 public sealed class MobileHoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler {
  public MobileDriveInput input; public DriveAction action;
  public void OnPointerDown(PointerEventData e){if(input)input.SetHeld(action,true);}
  public void OnPointerUp(PointerEventData e){Release();}
  public void OnPointerExit(PointerEventData e){Release();}
  void OnDisable()=>Release();
  void Release(){if(input)input.SetHeld(action,false);}
 }
}