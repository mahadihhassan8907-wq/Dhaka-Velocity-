using UnityEngine;
using UnityEngine.UI;
namespace DhakaVelocity {
 public sealed class CheckpointRaceManager : MonoBehaviour {
  public int total=5,next; public Text progressText, statusText;
  public void Pass(int index){if(index!=next)return;next++;if(progressText)progressText.text="CHECKPOINT "+next+"/"+total;if(statusText)statusText.text=next>=total?"RACE COMPLETE!":"CHECKPOINT CLEARED!";if(next>=total)Debug.Log("Dhaka Velocity: race complete");}
 }
 public sealed class CheckpointGate : MonoBehaviour {
  public int index; public CheckpointRaceManager manager;
  void OnTriggerEnter(Collider other){VehicleController v=other.GetComponentInParent<VehicleController>();if(v&&manager)manager.Pass(index);}
 }
}