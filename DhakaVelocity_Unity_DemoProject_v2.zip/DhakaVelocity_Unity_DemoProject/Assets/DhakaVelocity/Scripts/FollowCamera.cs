using UnityEngine;
namespace DhakaVelocity {
 public sealed class FollowCamera : MonoBehaviour {
  public Transform target; public Vector3 offset=new Vector3(0,4.5f,-8.5f); public float smooth=7f; public float lookHeight=1.1f; Camera cam; float baseFov;
  void Awake(){cam=GetComponent<Camera>();if(cam)baseFov=cam.fieldOfView;}
  void LateUpdate(){if(!target)return;float t=1-Mathf.Exp(-smooth*Time.deltaTime);Vector3 wanted=target.TransformPoint(offset);transform.position=Vector3.Lerp(transform.position,wanted,t);Vector3 look=target.position+Vector3.up*lookHeight+target.forward*2;transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(look-transform.position,Vector3.up),t);if(cam){Rigidbody r=target.GetComponent<Rigidbody>();float v=r?r.velocity.magnitude:0;cam.fieldOfView=Mathf.Lerp(cam.fieldOfView,baseFov+Mathf.Clamp(v/5,0,8),t);}}
 }
}