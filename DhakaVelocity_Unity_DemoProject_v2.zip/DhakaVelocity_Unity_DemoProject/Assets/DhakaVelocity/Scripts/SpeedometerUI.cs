using UnityEngine;
using UnityEngine.UI;
namespace DhakaVelocity {
 public sealed class SpeedometerUI : MonoBehaviour {
  public VehicleController vehicle; public Text speedText;
  void Update(){if(vehicle&&speedText)speedText.text=Mathf.RoundToInt(Mathf.Abs(vehicle.SpeedKmh))+" KM/H";}
 }
}