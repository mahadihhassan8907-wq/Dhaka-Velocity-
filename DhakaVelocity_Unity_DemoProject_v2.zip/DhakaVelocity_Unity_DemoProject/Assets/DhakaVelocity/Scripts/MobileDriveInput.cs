using UnityEngine;
namespace DhakaVelocity {
 public enum DriveAction { SteerLeft, SteerRight, Accelerate, Brake, Reverse, Nitro, Handbrake }
 public sealed class MobileDriveInput : MonoBehaviour {
  private readonly bool[] held = new bool[7];
  public bool IsHeld(DriveAction a) => held[(int)a];
  public void SetHeld(DriveAction a,bool v) => held[(int)a]=v;
  public void ReleaseAll(){for(int i=0;i<held.Length;i++)held[i]=false;}
  void OnDisable()=>ReleaseAll();
  void OnApplicationFocus(bool f){if(!f)ReleaseAll();}
  void OnApplicationPause(bool p){if(p)ReleaseAll();}
 }
}