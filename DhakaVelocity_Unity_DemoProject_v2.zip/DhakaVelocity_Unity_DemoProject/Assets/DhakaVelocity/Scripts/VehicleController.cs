using UnityEngine;
namespace DhakaVelocity {
 [RequireComponent(typeof(Rigidbody))]
 public sealed class VehicleController : MonoBehaviour {
  public MobileDriveInput mobileInput;
  public float acceleration=9000f, reverseAcceleration=4800f, brakeDeceleration=12f;
  public float maxForwardSpeed=35f, maxReverseSpeed=8f, steeringRate=100f, lateralGrip=8f, coastDrag=1.4f, nitroAcceleration=6500f, nitroMaxSpeed=44f;
  Rigidbody rb; float steer, throttle; bool brake, reverse, nitro, handbrake;
  public float SpeedKmh => rb ? Vector3.Dot(rb.velocity,transform.forward)*3.6f : 0f;
  void Awake(){rb=GetComponent<Rigidbody>();rb.mass=1200;rb.drag=.03f;rb.angularDrag=2.0f;rb.interpolation=RigidbodyInterpolation.Interpolate;rb.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;rb.constraints=RigidbodyConstraints.FreezeRotationX|RigidbodyConstraints.FreezeRotationZ;}
  void Update(){
   float keySteer=(Input.GetKey(KeyCode.D)||Input.GetKey(KeyCode.RightArrow)?1:0)-(Input.GetKey(KeyCode.A)||Input.GetKey(KeyCode.LeftArrow)?1:0);
   float touchSteer=mobileInput?(mobileInput.IsHeld(DriveAction.SteerRight)?1:0)-(mobileInput.IsHeld(DriveAction.SteerLeft)?1:0):0;
   steer=Mathf.Abs(touchSteer)>.01f?touchSteer:keySteer;
   throttle=(Input.GetKey(KeyCode.W)||Input.GetKey(KeyCode.UpArrow)||(mobileInput&&mobileInput.IsHeld(DriveAction.Accelerate)))?1:0;
   brake=Input.GetKey(KeyCode.S)||Input.GetKey(KeyCode.DownArrow)||(mobileInput&&mobileInput.IsHeld(DriveAction.Brake));
   reverse=Input.GetKey(KeyCode.R)||(mobileInput&&mobileInput.IsHeld(DriveAction.Reverse));
   nitro=Input.GetKey(KeyCode.LeftShift)||(mobileInput&&mobileInput.IsHeld(DriveAction.Nitro));
   handbrake=Input.GetKey(KeyCode.Space)||(mobileInput&&mobileInput.IsHeld(DriveAction.Handbrake));
  }
  void FixedUpdate(){
   Vector3 local=transform.InverseTransformDirection(rb.velocity); float forward=local.z;
   if(brake){local.z=Mathf.MoveTowards(forward,0,brakeDeceleration*Time.fixedDeltaTime);rb.velocity=transform.TransformDirection(local);}
   else if(reverse && Mathf.Abs(forward)<1.2f){rb.AddForce(-transform.forward*reverseAcceleration,ForceMode.Force);}
   else if(throttle>0 && forward<maxForwardSpeed){rb.AddForce(transform.forward*acceleration,ForceMode.Force);}
   else if(throttle<=0 && !reverse){Vector3 hv=new Vector3(rb.velocity.x,0,rb.velocity.z);rb.AddForce(-hv*coastDrag,ForceMode.Acceleration);}
   if(nitro&&throttle>0&&forward<nitroMaxSpeed)rb.AddForce(transform.forward*nitroAcceleration,ForceMode.Force);
   local=transform.InverseTransformDirection(rb.velocity);
   float grip=handbrake?1.5f:lateralGrip;
   local.x=Mathf.MoveTowards(local.x,0,grip*Time.fixedDeltaTime*Mathf.Max(1,Mathf.Abs(local.z)*.45f));
   float speedFactor=Mathf.Clamp01(Mathf.Abs(local.z)/4f);
   if(Mathf.Abs(local.z)>.35f)rb.MoveRotation(rb.rotation*Quaternion.Euler(0,steer*steeringRate*speedFactor*(local.z>=0?1:-1)*Time.fixedDeltaTime,0));
   float limit=local.z>=0?(nitro?nitroMaxSpeed:maxForwardSpeed):maxReverseSpeed;
   local.z=Mathf.Clamp(local.z,-maxReverseSpeed,limit);rb.velocity=transform.TransformDirection(local);
  }
  public void ResetAt(Transform point){if(!point)return;rb.velocity=Vector3.zero;rb.angularVelocity=Vector3.zero;rb.position=point.position;rb.rotation=point.rotation;if(mobileInput)mobileInput.ReleaseAll();}
 }
}