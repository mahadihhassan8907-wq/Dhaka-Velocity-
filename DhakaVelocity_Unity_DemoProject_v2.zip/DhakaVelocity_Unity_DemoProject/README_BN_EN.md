# Dhaka Velocity — Unity Android Demo Project Source

This is the next development step: a Unity Editor scene-builder plus gameplay scripts. It is **not an APK** and has not been compiled or device-tested here.

## Create the demo scene
1. Install Unity Hub and a Unity 6 LTS Editor with Android Build Support, Android SDK & NDK Tools, and OpenJDK.
2. Create a new **Universal 3D (URP)** project.
3. Copy `Assets/DhakaVelocity` from this package into the project's `Assets/` folder.
4. Wait for Unity to compile scripts.
5. In Unity, choose **Dhaka Velocity → Build Playable Demo Scene**.
6. Press Play. Keyboard controls: W/Up accelerate, A/D or arrows steer, S/Down brake, R reverse, Left Shift nitro, Space handbrake.
7. For Android, install Android Build Support modules, switch Build Settings to Android, set package identifier, use ARM64, and build an APK for device testing.

## Included
- Rigidbody arcade vehicle controller; braking stops at zero and reverse is a separate deliberate action.
- Touch hold buttons with release on pointer exit, disable, app pause/focus loss.
- Smooth third-person follow camera with speed FOV.
- Editor scene builder: blockout city, roads, buildings, car, camera, HUD/touch controls, checkpoints, basic traffic movers.
- Checkpoint progression and speedometer.

## Important known limitations
- Greybox only: no final car art, detailed Dhaka landmarks, production city assets, sound design, polished UI, garage, missions, save system, or online multiplayer yet.
- Traffic movement is deliberately simple and does not yet avoid the player or other traffic.
- Checkpoint geometry and route are a first-pass test course.
- The Editor builder uses built-in legacy UI Text and StandaloneInputModule for broad compatibility. If the project is configured exclusively for the new Input System, set Active Input Handling to Both or adapt the EventSystem module.
- URP quality, shadows, anti-aliasing, texture compression, LODs and thermal behavior must be profiled on the target Moto G67 Power 5G.
- No 100–200 MB size guarantee; final package size depends on engine version and art/audio assets.
- Online multiplayer remains a separate server/network engineering phase.
